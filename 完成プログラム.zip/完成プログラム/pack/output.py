# coding:utf-8
import cv2
import ctypes #解像度取得用

def output(img, route, start, goal):
    for e in route:
        cv2.line(img, e[0], e[1], (255,200,0) ,3)

    cv2.circle(img, start, 7, (0,0,255), -1)
    cv2.circle(img, goal, 7, (255,0,0), -1)

    user32 = ctypes.windll.user32
    winw = user32.GetSystemMetrics(0) #横幅
    winh = user32.GetSystemMetrics(1) #縦幅
    height, width = img.shape[:2]
   
    cv2.imshow("output", img) #画像を表示
    cv2.moveWindow("output", (int)((winw-width)/2), (int)((winh-height)/2))
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    cv2.imwrite('output.png', img)

