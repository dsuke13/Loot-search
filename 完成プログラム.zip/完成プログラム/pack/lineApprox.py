# coding:utf-8
import cv2
import math

#折れ線近似
class LineApprox():
    #点と直線の距離を返す
    def __calcLinePoint(self, line_start, line_goal, point):
        #(a,b),(c,d)を通る直線の方程式
        #a!=cのとき y-b = (d-b)/(c-a)*(x-a)
        #変形して {-(d-b)/(c-a)}x + y + {-b + (d-b/c-a)*a} = 0
        #a==cのとき x=a
        #変形して x - a = 0
        #直線 ax+by+c=0 と(p,q)の距離
        # | ap+bq+c | / sqrt(a^2+b^2)
        xs, ys = line_start #始点
        xg, yg = line_goal #終点
        if xs==xg:
            a = 1
            b = 0
            c = -xs
        else:
            a = -(yg - ys)/(xg - xs)
            b = 1
            c = (yg - ys)/(xg - xs)*xs - ys
        p, q = point #注目点の座標
        return abs(a*p + b*q + c)/ math.sqrt(a*a + b*b) #距離

    #画素列始点終点間の直線から最遠の点のインデックスとその距離を返す
    def __searchMaxDistance(self, row):
        l = len(row)
        maximum = 0
        max_point = None
        for dot in row:
            h = self.__calcLinePoint(row[0], row[l-1], dot)
            if h > maximum:
                maximum = h
                max_point = dot
            # if maximum == 0:#画素列の点がすべて一直線で結ばれていたら
            #     max_point = row[0]#この場合max_pointはいらないが、返すために適当に入れておく
        return max_point, maximum

    #1つのセグメントについて折れ線近似
    def __approx1(self, v, e, row):
        l = len(row)
        if l < 10: #短ければ
            v.add(row[0])
            v.add(row[l-1])
            e.add((row[0], row[l-1]))
            return v, e #そのまま返す
        else:
            split_lst = []#lstの要素を分割していく

            if row[0] == row[l-1]:#環状なら最初に半分に分ける
                r = (int)(l/2)
                self.__approx1(v, e, row[:r])
                self.__approx1(v, e, row[r-1:])
                return v, e

            else:
                split_lst.append([row[0], row[l-1]])

            while split_lst != []:#分割できなくなるまで
                for i in split_lst:
                    index1 = row.index(i[0])
                    index2 = row.index(i[1]) + 1

                    if index2 - index1 < 3:
                        v.add(i[0])
                        v.add(i[1])
                        e.add((i[0], i[1]))
                        split_lst.remove(i)
                    
                    else:
                        split_row = row[index1:index2]

                        max_point, maximum = self.__searchMaxDistance(split_row)

                        if maximum > 1:
                            p = i.pop(1)
                            i.append(max_point)
                            split_lst.append([max_point, p])
                        else:#直線またはほぼ直線の場合
                            v.add(i[0])
                            v.add(i[1])
                            e.add((i[0], i[1]))
                            split_lst.remove(i)#これ以上分割する必要がないのでlstから消す

        return v, e

    #折れ線近似
    def lineApprox(self, segment):
        v = set()
        e = set()
        for row in segment:
            v, e = self.__approx1(v, e, row)
        return v, e
