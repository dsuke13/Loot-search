# coding:utf-8
import cv2  #open cv
import copy #リストのコピー

class Segment():
    def __init__(self):
        #定数を定義
        self.__PASSING = 1 #通過点
        self.__C_PASSING = 5 #通過点候補
        self.__JUNCTION = 10 #分岐点
        self.__C_JUNCTION = 110 #分岐点候補
        self.__TERMINUS = 20 #端点
        self.__C_TERMINUS = 120 #端点候補
        self.__NOTROAD = 0 #道でない画素
        self.__EFFECTIVE = 255 #未訪問点(有効画素)
        #方向コード 右:0 右下:1 下:2 ... 右上:7
        self.__ANG = ((1,0), (1,1), (0,1), (-1,1), (-1,0), (-1,-1), (0,-1), (1,-1))

    #左上から有効画素を探し，返す
    def __searchStartPoint(self, flag):
        y = -1
        for hor in flag:
            y += 1
            x = -1
            for ele in hor:
                x += 1
                if ele==self.__EFFECTIVE:
                    return (x,y)
        return None

    #pointの近傍にある有効画素を取得、方向と座標を開始点集合start_stackに積む
    def __addStartStack(self, flag, point, start_stack):
        x, y = point #pointは画像の縁であってはならない
        cnt = 0 #道である画素のカウンタ
        effec_cnt = 0 #有効画素のカウンタ
        #周辺の有効画素を探索
        for i in range(8):
            xi = x+self.__ANG[i][0]
            yi = y+self.__ANG[i][1]
            ele = flag[yi][xi]
            if ele!=self.__NOTROAD:
                cnt += 1
            if ele==self.__EFFECTIVE:
                effec_cnt += 1 #有効画素を数える
                start_stack.add(((xi, yi), i)) #集合に格納
        
        if cnt==0: #周囲のすべてが道でない時
            flag[y][x] = self.__NOTROAD #この点は孤立点
        elif cnt==1 and effec_cnt==1: #周囲に1点だけで，有効画素であるとき
            flag[y][x] = self.__TERMINUS #端点
        elif cnt==1 and effec_cnt==0: #周囲に有効画素じゃないのが1つだけ(こんなことある？)
            flag[y][x] = self.__C_TERMINUS #test
            #print("addStartStack: self.__C_TERMINUS({},{})".format(x,y))
        elif cnt>1 and effec_cnt==1:
            flag[y][x] = self.__C_PASSING #test
            #print("addStartStack: self.__C_PASSING({},{})".format(x,y))
        else: #その他
            flag[y][x] = self.__JUNCTION #分岐点
        return flag, start_stack

    #followEdgeの補助関数 開始点集合に指定した座標が含まれているか調べ，含まれているならば開始点を返す
    def __checkStartStack(self, x, y, start_stack):
        for i in range(8):
            if ((x,y), i) in start_stack:
                return ((x,y), i)
        return None

    #開始点集合から1つ取り出し、有効画素をたどる
    def __followEdge(self, flag, start_stack):
        point, ang_code = start_stack.pop() #開始点集合から取り出す
        x, y = point #最初の注目点、即ち開始点の隣
        res_row = [(x-self.__ANG[ang_code][0], y-self.__ANG[ang_code][1])] #返す画素列(セグメント)、開始点は格納しておく

        if flag[y][x]==self.__PASSING: #最初の注目点が通過点だったら
            return flag, [] #何もしないで空リストを返す
        elif flag[y][x]==self.__JUNCTION: #分岐点なら
            res_row.append( point )
            return flag, res_row #開始点と最初の注目点からなるセグメントを返す

        isFirst = True
        while True:
            x, y = point #今注目している点
            pre_ang_code = (ang_code + 4) % 8 #やってきた方向コード(注目している点視点)
            cnt = 0 #道でない画素以外の画素のカウンタ(つまり種類に依らす道である画素のカウンタ)
            effec_cnt = 0 #未訪問点のカウンタ
            effec_point = [] #未訪問点のスタック
            pass_cnt = 0 #通過点のカウンタ
            c_pass_cnt = 0 #通過点候補のカウンタ
            jct_cnt = 0 #分岐点のカウンタ
            jct_point = [] #分岐点のスタック
            for i in range(7): 
                #whileループの初回のみ次を実行
                if isFirst and flag[res_row[0][1]][res_row[0][0]]==self.__JUNCTION: #画素列の始点が分岐点なら
                    #注目点が0,6番目(注目点が4近傍でやってきた場合は1,5番目も)に見る点は，始点である分岐点の分岐先であるかもしれない
                    #よってそれらが分岐先である場合は，注目点がたどれないようにする．
                    if i==0 or i==6 or (pre_ang_code%2==0 and (i==1 or i==5)):
                        j = (pre_ang_code + i + 1) % 8 #具体的方向に変換
                        #見る点が分岐先に含まれているか調べる
                        if self.__checkStartStack(x+self.__ANG[j][0], y+self.__ANG[j][1], start_stack)!=None: #含まれていたら
                            continue #その方向をたどらない
                #やってきた方向から右回りで
                i = (pre_ang_code + i + 1) % 8
                xi = x + self.__ANG[i][0]
                yi = y + self.__ANG[i][1] #注目点の周りの座標
                ele = flag[yi][xi] #注目点の周りの画素
                if ele!=self.__NOTROAD: #道の画素
                    cnt += 1
                if ele==self.__EFFECTIVE: #未訪問点
                    effec_cnt += 1
                    effec_point.append(((xi, yi), i)) #スタックに次の点と方向コードを積む
                elif ele==self.__PASSING: #通過点
                    pass_cnt += 1
                elif ele==self.__C_PASSING: #通過点候補
                    c_pass_cnt += 1
                elif ele==self.__JUNCTION: #分岐点
                    jct_cnt += 1
                    jct_point.append(((xi, yi), i)) #スタックに積む
            isFirst = False #初回のみのフラグを下げる

            #返却用スタックに注目点を積む
            res_row.append(point)
            #点の判定は強い条件から先に判定する．
            if cnt==0: #行く先に道すらないとき
                flag[y][x] = self.__TERMINUS #必ず端点
                break #たどり終了
            if effec_cnt==1 and cnt==1: #次の道が確定のとき
                flag[y][x] = self.__PASSING #通過点
                point, ang_code = effec_point.pop() #注目点を次に移す
                continue #次のループへ
            if effec_cnt==2 and cnt - pass_cnt==2: #未訪問点2つ
                ang = [ang for _,ang in effec_point]
                #2つの未訪問点が隣接ならば、4近傍を優先的にたどる
                if ang[0] +1 ==ang[1] or (ang[0]==7 and ang[1]==0): #隣接ならば先に4近傍をたどる
                    flag[y][x] = self.__PASSING #注目点は通過点
                    if ang[0] % 2==0:
                        point, ang_code = effec_point[0] #注目点を次に
                    else:
                        point, ang_code = effec_point[1]
                    continue
                else: #隣接でなければ
                    flag[y][x] = self.__JUNCTION #分岐点
                    for p in effec_point:
                        start_stack.add( p ) #開始点集合に積む
                    break
            if effec_cnt==3 and cnt - pass_cnt==3: #未訪問点3つ
                ang = [ang for _,ang in effec_point]
                #3つの未訪問点が隣接ならば、4近傍を優先的にたどる
                if (ang[0], ang[1], ang[2]) in {(1,2,3), (3,4,5), (5,6,7), (7,0,1)}:
                    flag[y][x] = self.__PASSING #通過点
                    point, ang_code = effec_point[1] #3つが連接ならば真ん中の画素へ移動
                    continue
                else: #隣接でなければ
                    flag[y][x] = self.__JUNCTION #分岐点
                    for p in effec_point:
                        start_stack.add( p ) #開始点集合に積む
                    break

            if jct_cnt==1 and effec_cnt==0: #周囲に分岐点が含まれるとき
                start_point = self.__checkStartStack(x, y, start_stack) #注目点が開始点集合に含まれているか調べる
                if start_point!=None: #含まれているなら
                    flag[y][x] = self.__PASSING #注目点は通過点
                    myAng = (start_point[1] +4) %8 #見つかった方向を注目点視点に変換
                    res_row.append((x+self.__ANG[myAng][0], y+self.__ANG[myAng][1])) #その分岐点までセグメントに含めて終了
                    start_stack.discard(start_point) #既にセグメントに含めたので開始点集合から削除
                else: #含まれていないなら
                    flag[y][x] = self.__JUNCTION
                    start_stack.add( jct_point[0] ) #分岐点への開始点を積む
                    #print("followEdge: jct:1 eff:0 set self.__JUNCTION({},{})".format(x,y)) #test
                break
            if jct_cnt==1 and effec_cnt>0: #有効画素と分岐点があるとき
                flag[y][x] = self.__JUNCTION #分岐点
                for p in effec_point:
                    start_stack.add( p ) #未訪問点への開始点を積む
                if self.__checkStartStack(x, y, start_stack)==None: #注目点が開始点集合に含まれないなら
                    start_stack.add( jct_point[0] ) #分岐点への開始点を積む
                break
            if jct_cnt>2:
                flag[y][x] = self.__JUNCTION #分岐点
                for q in effec_point:
                    start_stack.add( q ) #未訪問点への開始点を積む
                for p in jct_point: 
                    start_stack.add( p ) #分岐点への開始点を積む
                    start_stack.discard(((x,y), ( p[1] +4) %8 )) #今積んだ開始点に向かう方向の開始点を削除
                #print("followEdge: jct:{} eff:{} set self.__JUNCTION ({},{})".format(jct_cnt,effec_cnt,x,y)) #test
                break
            if effec_cnt==0 and cnt>0: #有効画素がないが，道が複数あるとき
                flag[y][x] = self.__JUNCTION #とりあえず分岐点にしとく
                break #たどり終了
            
            if effec_cnt==1 and (c_pass_cnt==0 or cnt-pass_cnt==1): #未訪問点があるとき(弱い)
                flag[y][x] = self.__PASSING
                point, ang_code = effec_point.pop()
                continue
            if effec_cnt>1: #未訪問点が複数あるとき(弱い)
                flag[y][x] = self.__JUNCTION #とりあえず分岐点にしとく
                for p in effec_point:
                    start_stack.add( p ) #開始点集合に積む
                break

            #上の条件全てに当てはまらないとき
            flag[y][x] = self.__C_PASSING #通過点候補
            #print("followEdge: notice self.__C_PASSING({},{})".format(x,y)) #test
            point, ang_code = effec_point[0] #最初に見つかったやつにしとく
            
        return flag, res_row
    
    #セグメントを探す
    def searchSegment(self, skeleton, start, goal):
        skel = copy.deepcopy(skeleton) #与えられた細線化画像を完全にコピー
        stack = set() #開始点集合
        res = [] #得られたセグメント(画素列)を格納するリスト

        skel, stack = self.__addStartStack(skel, goal, stack) #ゴール周りの開始点を積む
        start_point = start #最初の開始点はスタート点
        while start_point!=None: #開始点が見つからなくなるまで繰り返す
            skel, stack = self.__addStartStack(skel, start_point, stack) #開始点を開始点集合に積む
            while len(stack)>0:
                skel, pxrow = self.__followEdge(skel, stack) #画素列と方向コード列を得る
                if pxrow!=[]:
                    res.append(pxrow) #得られたセグメントを格納
            start_point = self.__searchStartPoint(skel) #次の開始点を探す
        return res

