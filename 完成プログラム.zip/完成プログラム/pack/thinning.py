# coding:utf-8
import cv2

#グレースケール画像を読み込み細線化した画像を返す
def thinning(img):
    height, width = img.shape[:2] #サイズを取得
    #画像の縁を黒にする(ここ大事)
    for i in range(width):
        img[0][i] = 0
        img[height-1][i] = 0
    for i in range(height):
        img[i][0] = 0
        img[i][width-1] = 0

    skeleton = cv2.ximgproc.thinning(img, thinningType=cv2.ximgproc.THINNING_ZHANGSUEN) #細線化
    return skeleton
