# coding:utf-8
import math
from concurrent import futures

class Map:
    def __init__(self,start,goal,vertex,edge):
        self.__start = start
        self.__goal = goal
        self.__v_set = vertex #座標のみ頂点の集合
        self.__e_set = edge #辺の集合
        self.__res_start = []
        self.__res_goal = []
        self.__key = 0
        self.__dec_set = set()
        self.__terminal = None
    
    #頂点間の推定距離を計算
    def __calcD(self, v, crt_point): #crt_pointは現在のスタートorゴール

        x = v[0] - crt_point[0]
        y = v[1] - crt_point[1]

        return math.sqrt(x*x + y*y)

    def __koushin(self, dec_v, undec_list, e_set, crt_point):  #crt_pointは現在のスタートorゴール
        for v in undec_list:
            if (dec_v[0], v[0]) in e_set:
                kyori = self.__calcD(dec_v[0], v[0]) #辺の距離を要求
                if v[1] > kyori + dec_v[1]:
                    v[1] = kyori + dec_v[1] 

                    v[2] = v[1] + self.__calcD(v[0], crt_point) #変数を変更
                    
                    v[3] = [v[0]] + dec_v[3]
            elif (v[0], dec_v[0]) in e_set:
                kyori = self.__calcD(dec_v[0], v[0])
                if v[1] > kyori + dec_v[1]:
                    v[1] = kyori + dec_v[1]
                    v[2] = v[1] + self.__calcD(v[0], crt_point) 
                    v[3] = [v[0]] + dec_v[3]
        return undec_list

    def __input_set(self,p):
        while self.__key == 1:
            pass
        self.__key = 1
        self.__dec_set.add(p)
        self.__key = 0 
        
        
    def __Astar_start(self, v_set, e_set): 
        #確定集合 dec_route_list
        dec_route_list = [ [self.__start, 0, float('inf'), [self.__start]]]
        #未確定集合 undec_route_list
        v_list = list(v_set) #セットをリストに変換
        undec_route_list = [ [id, float('inf'), float('inf'), [id]] for id in v_list if id!=self.__start]
        #最初はスタート頂点から始める
        p = dec_route_list[0]

            
        self.__koushin(p, undec_route_list, e_set, self.__goal)

        min = float('inf')
        for [id, weight, cost, route] in undec_route_list:
            if cost!=float('inf') and min>cost:
                min = cost
                index = undec_route_list.index([id, weight, cost, route])
        p = undec_route_list[index]

        dec_route_list.append(p)
        undec_route_list.remove(p)
        

        while p[0] not in self.__dec_set() and self.__terminal == None:

            #self.__dec_set.add(p[0]) #追加12/09
            self.__input_set(p[0])

            
            self.__koushin(p, undec_route_list, e_set, self.__goal)

            #次に確定集合から距離最小の頂点を求める
            min = float('inf')
            for [id, weight, cost, route] in undec_route_list:
                if cost!=float('inf') and min>cost:
                    min = cost
                    index = undec_route_list.index([id, weight, cost, route])

            p = undec_route_list[index]    #最小頂点pを見つけた

            dec_route_list.append(p) #pを確定集合に追加
            undec_route_list.remove(p) #pを未確定集合から削除

        #ゴールからスタートまでの経路を探す
        if self.__terminal == None:
            self.__terminal = p[0]
            
        for [id, _, _, route] in dec_route_list:
            if id == self.__terminal: #if文ある方が速い(元に戻す)
                self.__res_start = route
        
    def __Astar_goal(self, v_set, e_set):
        #確定集合 dec_route_list
        dec_route_list = [ [self.__goal, 0, float('inf'), [self.__goal]]]
        #未確定集合 undec_route_list
        v_list = list(v_set)
        undec_route_list = [ [id, float('inf'), float('inf'), [id]] for id in v_list if id!=self.__goal]
        #最初はスタート頂点から始める
        p = dec_route_list[0]

        
        self.__koushin(p, undec_route_list, e_set, self.__goal)

        if self.__terminal == None:
            min = float('inf')
            for [id, weight, cost, route] in undec_route_list:
                if cost!=float('inf') and min>cost:
                    min = cost
                    index = undec_route_list.index([id, weight, cost, route])
            p = undec_route_list[index]
        
            dec_route_list.append(p)
            undec_route_list.remove(p)
        

        while p[0] not in self.__dec_set and self.__terminal == None:

  
            self.__input_set(p[0])
            self.__koushin(p, undec_route_list, e_set, self.__start)
            #次に確定集合から距離最小の頂点を求める
            min = float('inf')
            for [id, weight, cost, route] in undec_route_list:
                if cost!=float('inf') and min>cost:
                    min = cost
                    index = undec_route_list.index([id, weight, cost, route])
           
            p = undec_route_list[index]    #最小頂点pを見つけた
            

            dec_route_list.append(p) #pを確定集合に追加
            undec_route_list.remove(p) #pを未確定集合から削除
        #ゴールからスタートまでの経路を探す
        if self.__terminal == None:
            self.__terminal = p[0]

        for [id, _, _, route] in dec_route_list:
            if id == self.__terminal: 
                self.__res_goal = route

      

    def kensaku(self):
        
        self.__dec_set.add(self.__start)
        self.__dec_set.add(self.__goal)
        
        future_list = []
        with futures.ThreadPoolExecutor(max_workers=2) as executor:
            future = executor.submit(self.__Astar_start,self.__v_set,self.__e_set)
            future_list.append(future)
            future = executor.submit(self.__Astar_goal,self.__v_set,self.__e_set)
            future_list.append(future)

            _ = futures.as_completed(future_list)


        res = list(dict.fromkeys(list(reversed(self.__res_goal)) + self.__res_start))


        res_set =set()
        
        for i in range(len(res)-1):
            res_set.add((res[i],res[i+1]))
        return res_set

