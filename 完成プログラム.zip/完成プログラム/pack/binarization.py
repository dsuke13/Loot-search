# coding:utf-8
import cv2
import numpy as np
import ctypes #解像度取得用

class Binary():
    #白い道の部分を抽出したマスク画像(2値化画像)を返す
    def __extractRoad(self, img):
        lower = np.array([250,250,250])
        upper = np.array([255,255,255])
        img_mask = cv2.inRange(img, lower, upper)
        kernel = np.array([[0,1,0],[1,1,1],[0,1,0]], np.uint8) #近傍の定義
        img_mask = cv2.morphologyEx(img_mask, cv2.MORPH_CLOSE, kernel) #クロージング
        return img_mask

    #黄色い道(国道)の部分を抽出したマスク画像を返す
    def __extractYellow(self, img):
        lower = np.array([179,232,245])
        upper = np.array([199,252,255])
        img_mask = cv2.inRange(img, lower, upper)
        kernel = np.array([[0,1,0],[1,1,1],[0,1,0]], np.uint8) #近傍の定義
        img_mask = cv2.morphologyEx(img_mask, cv2.MORPH_CLOSE, kernel) #クロージング
        return img_mask

    #オレンジの道(高速道路)の部分を抽出したマスク画像を返す
    def __extractOrange(self, img):
        lower = np.array([118,196,233])
        upper = np.array([138,216,245])
        img_mask = cv2.inRange(img, lower, upper)
        kernel = np.array([[0,1,0],[1,1,1],[0,1,0]], np.uint8) #近傍の定義
        img_mask = cv2.morphologyEx(img_mask, cv2.MORPH_CLOSE, kernel) #クロージング
        return img_mask

    #グリーンの道(歩道)の部分を抽出したマスク画像を返す
    def __extractGreen(self, img):
        lower = np.array([106,175,81])
        upper = np.array([126,195,101])
        img_mask = cv2.inRange(img, lower, upper)
        kernel = np.array([[0,1,0],[1,1,1],[0,1,0]], np.uint8) #近傍の定義
        img_mask = cv2.morphologyEx(img_mask, cv2.MORPH_CLOSE, kernel) #クロージング
        return img_mask
    
    #画像を読み込み2値化する
    def binarization(self, path):
        img = cv2.imread(path)
        if img is None: #画像を読み込めなかったとき
            raise Exception("Nor found file...") #例外を投げる

        #画面の解像度サイズに適した画像サイズに変更(元画像が大きすぎるため、ピクセル数を減らして負荷を軽減ため)------------------------------
        user32 = ctypes.windll.user32
        winw = user32.GetSystemMetrics(0) #横幅
        winh = user32.GetSystemMetrics(1) #縦幅

        margin = 100 #画像の上と左を何ピクセル余裕を持たせるか

        height = int(img.shape[0]) #縦幅
        width = int(img.shape[1]) #横幅

        ratio = width / height #画像の縦横比

        if(winh < height):
            height = winh - (2*margin)
            width = int(height * ratio)

        if(winw < width):
            width = winw - (2*margin)
            height = int(width / ratio)

        img = cv2.resize(img, (width,height)) #resizeを使い,画像サイズを変更(img2と新たに置く)

        ##国道(オレンジ)、高速道路(イエロー)、歩道(グリーン)を道として認識する-----------------------------------
        white_mask = self.__extractRoad(img)
        img_white = cv2.bitwise_and(img, img, mask=white_mask) #白い道の部分を抽出
        yellow_mask = self.__extractYellow(img)
        img_yellow = cv2.bitwise_and(img, img, mask=yellow_mask) #黄色い道(国道)の部分を抽出
        orange_mask = self.__extractOrange(img)
        img_orange = cv2.bitwise_and(img, img, mask=orange_mask) #オレンジの道(高速道路)の部分を抽出
        green_mask = self.__extractGreen(img)
        img_green = cv2.bitwise_and(img, img, mask=green_mask) #グリーンの道(歩道)の部分を抽出

        #マスク画像の結合
        img_road = cv2.bitwise_or(white_mask, yellow_mask)
        img_road = cv2.bitwise_or(img_road, orange_mask)
        img_road = cv2.bitwise_or(img_road, green_mask)
        kernel = np.array([[0,1,0],[1,1,1],[0,1,0]], np.uint8) #近傍の定義
        img_road = cv2.morphologyEx(img_road, cv2.MORPH_CLOSE, kernel) #クロージング

        #画像の色変換(二値化(真っ白と真っ黒の二色で表現)、全てピクセルの色表記が(0)or(255)となる)------------------
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) #RGB画像をグレースケール画像(変数名gray)に変換
        _,two = cv2.threshold(gray, 250, 255, cv2.THRESH_BINARY) #グレースケール画像を二値化画像(変数名two)に変換
        """
            threshold(閾値)関数の説明
                第一引数:グレースケール画像(RGBは×)
                第二引数:この引数より小さい値(明度)のピクセルを(0)、大きい値のピクセルを(255)にする
                第三引数:ピクセルの最大値(白黒ならば255にしておけば問題ない)
                第四引数:閾値処理の方法(他にはTHRESH_TRUNCなどがある)

                第一出力値:？？？？？？
                第二出力値:二値化画像
        """
        #返り値の設定----------------------------------------------------------------------------------------
        return img, img_road
            