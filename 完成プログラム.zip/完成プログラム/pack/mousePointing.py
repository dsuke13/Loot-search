# coding:utf-8
import cv2 #openCV
import math
import ctypes #解像度取得用

class MousePointing: #マウス指定を行うクラス
    def __init__(self): #とりあえず変数を定義
        self.__img = None
        self.__skel = None
        self.__start = None
        self.__goal = None

    def __startClick(self, event,x,y,flags,param):
        if event==cv2.EVENT_LBUTTONDOWN:
            self.__start = self.__lineCheck(x,y,self.__skel) #ここで座標を取得
            if self.__start != None: #取得できたならば
                cv2.circle(self.__img, self.__start, 7, (0,0,255), -1)
            cv2.destroyWindow("firstClick") #ウィンドウを閉じる

    def __goalClick(self, event,x,y,flags,param):
        if event==cv2.EVENT_LBUTTONDOWN:
            self.__goal = self.__lineCheck(x,y,self.__skel)
            if self.__goal != None:
                cv2.circle(self.__img, self.__goal, 7, (255,0,0), -1)
            cv2.destroyWindow("secondClick")

    def __lineCheck(self, x, y, skel):
        if x<0 or x>=skel.shape[1]: #範囲外
            return None
        if y<0 or y>=skel.shape[0]:
            return None
        if skel[y][x]==255: #クリックした画素が道なら
            return (x, y) #その座標を返す
        else:
            minLength = float('inf') #最小長さを格納
            minPoint = None #長さ最小のときの座標を格納
            #ピクセル四方の正方形を想定
            for i in range(y-int(skel.shape[0]/30), y+int(skel.shape[0]/30)):
                if i<0: #範囲外
                    continue
                if i>=skel.shape[0]:
                    break
                for j in range(x-int(skel.shape[1]/30), x+int(skel.shape[1]/30)):
                    if j<0: #範囲外
                        continue
                    if j>=skel.shape[1]:
                        break
                    if skel[i][j]==255:
                        length = math.sqrt((i-y)**2+(j-x)**2) #2点間の距離
                        if length < minLength:
                            minLength = length #最小長さを更新
                            minPoint = (j,i)
            if minPoint==None: #取得できないなら
                print("road is too far") #test 本来はいらないかも
                return None
            return minPoint

    def pointing(self, img, skel):
        self.__img = img
        self.__skel = skel
        self.__start = None
        self.__goal = None
        user32 = ctypes.windll.user32
        winw = user32.GetSystemMetrics(0) #横幅
        winh = user32.GetSystemMetrics(1) #縦幅
        height, width = img.shape[:2]
        while self.__start==None: #スタート点を取得
            cv2.imshow('firstClick', img)
            cv2.moveWindow("firstClick", (int)((winw-width)/2), (int)((winh-height)/2))
            cv2.setMouseCallback('firstClick', self.__startClick)
            cv2.waitKey(0)

        while self.__goal==None: #ゴール点を取得
            cv2.imshow('secondClick', img)
            cv2.moveWindow("secondClick", (int)((winw-width)/2), (int)((winh-height)/2))
            cv2.setMouseCallback('secondClick', self.__goalClick)
            cv2.waitKey(0)

        return self.__start, self.__goal

