# coding:utf-8
import sys #途中終了
import pack

print("Please enter file name: ", end='')
path = input().strip() #標準入力から画像ファイル名を読み込む


print("Binarization...") #test
bnrClass = pack.bnr.Binary()
try:
    img, two = bnrClass.binarization(path) #二値化
except:
    sys.exit("Not found file...") #ファイルが読み込めない時終了


print("Thinning...")
skel = pack.thin.thinning(two) #細線化


print("MousePointing...")
mpClass = pack.mouse.MousePointing()
start, goal = mpClass.pointing(img, skel) #マウス指定


print("SegmentSplit...")
segmClass = pack.segm.Segment()
segment = segmClass.searchSegment(skel, start, goal) #セグメント分割


print("LineApprox...")
apprClass = pack.appr.LineApprox()
v, e = apprClass.lineApprox(segment) #折れ線近似


print("Aster...")
astarClass = pack.astar.Map(start, goal, v, e)
answer = astarClass.kensaku() #経路探索


pack.otpt.output(img, answer, start, goal) #結果表示